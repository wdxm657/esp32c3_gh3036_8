/* SPI Master Half Duplex EEPROM example.

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"

#include "sdkconfig.h"
#include "esp_log.h"
#include "gh_demo_api.h"

/*
 This code demonstrates how to use the SPI master half duplex mode to read/write a AT932C46D EEPROM (8-bit mode).
*/

//////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////// Please update the following configuration according to your HardWare spec /////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
#if CONFIG_IDF_TARGET_ESP32
#  if CONFIG_EXAMPLE_USE_SPI1_PINS
#   define EEPROM_HOST      SPI1_HOST
// Use default pins, same as the flash chip.
#   define PIN_NUM_MISO     7
#   define PIN_NUM_MOSI     8
#   define PIN_NUM_CLK      6
#  else
#   define EEPROM_HOST      SPI2_HOST
#   define PIN_NUM_MISO     18
#   define PIN_NUM_MOSI     23
#   define PIN_NUM_CLK      19
#  endif
#  define PIN_NUM_CS        13
#else
#  define EEPROM_HOST       SPI2_HOST
#  define PIN_NUM_MISO      13
#  define PIN_NUM_MOSI      12
#  define PIN_NUM_CLK       11
#  define PIN_NUM_CS        10
#endif

static const char TAG[] = "main";

void app_main(void)
{

    ESP_LOGI(TAG, "GH3036 SDK Demo Start");
    gh_app_demo_init();
    gh_app_demo_start(GH_FUNC_SLOT_EN);
    while (1) {
        // Add your main loop handling code here.
        vTaskDelay(1000);
        gh_app_demo_int_process();
    }
}
